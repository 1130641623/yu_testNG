package com.course.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration                                      //加载配置文件的注解，固定写法
@EnableSwagger2                                     //加载配置文件的注解，固定写法
public class SwaggerConfig {
    /** Swagger的配置文件
     * SpringBoot入口启动后，浏览器访问Swagger接口：http://localhost:8888/swagger-ui.html*/

    @Bean
    public Docket api(){
        return new Docket(DocumentationType.SWAGGER_2)  //DocumentationType.SWAGGER_2 是要在下面实现的
                // apiInfo()是要在下面实现的方法，它是用来配置接口文档的基本信息，这些信息都是自定义
                //pathMapping()配置访问路径
                //paths()方法是匹配在server里面访问方法的路径，是一个路径选择器，/.*表示选择所有路径/接口
                .apiInfo(apiInfo())
                .pathMapping("/")
                .select()
                .paths(PathSelectors.regex("/.*"))
                .build();
    }

    private ApiInfo apiInfo() {
        return  new ApiInfoBuilder().title("我的接口文档title")
                .contact(new Contact("dazhou","","42197393@qq.com"))
                .description("这是我的swaggerui生成的接口文档")
                .version("1.0.0.0")
                .build();

    }
}

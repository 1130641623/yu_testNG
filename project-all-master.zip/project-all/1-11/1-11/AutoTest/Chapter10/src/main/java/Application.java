

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

//Chapter10本章主要讲解SpringBoot的应用和接口编写、Swagger接口文档生成
/** *@ComponentScan该注解默认会扫描该类所在的包下所有的配置类,扫描装配标识了@Controller，@Service，@Repository的类
 *  我们在扫描路径下编写接口类，在 Application 入口类运行接口服务，接口访问路径在被扫描的接口类中，端口后在application.properties中
 *  访问示例，入口类启动服务后，浏览器访问：http://localhost:8888//getCookies */

@SpringBootApplication
@ComponentScan("com.course")
public class Application {                      //如果Application类名出现红色波浪线，表示该类在默认包下，运行不会报错
                                                //需要放在自己建的包下，红色波浪线才会消除
    public static void main(String[] args) {                        //SpringBoot入口类的固定写法
        SpringApplication.run(Application.class,args);
    }
}

package com.course.server;

import com.course.bean.User;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@RestController
@Api(value = "/",description = "这是我全部的post请求")
@RequestMapping("/v1")                //加了这个 v1，下面的全部方法的完整请求路径 =  v1 +  方法上的@RequestMapping注解里面的路径
public class MyPostMethod {
    //@RequestMapping注解是方法请求路径，用jmeter发起请求，需要用 类路径 + 方法路径。如/v1/login | /v1/getUserList
    //同时注意jmeter请求头的Content-Type

    //这个变量是用来装我们cookies信息的
    private static Cookie cookie;

    //用户登陆成功获取到cookies，然后再访问其他接口获取到列表
    //@RequestParam注解：required = true,表示必传参数
    //@RequestParam参数，对应jmeter里面的Parameters
    @RequestMapping(value = "/login",method = RequestMethod.POST)
    @ApiOperation(value = "登陆接口，成功后获取cookies信息",httpMethod = "POST")
    public String login(HttpServletResponse response,
                        @RequestParam(value = "userName",required = true) String userName,
                        @RequestParam(value = "password",required = true)  String password){
        if(userName.equals("zhangsan") && password.equals("123456")){
            cookie = new Cookie("login","true");                   //创建cookie对象
            response.addCookie(cookie);                                          //如果验证通过，就把cookie返回给客户端
            return "恭喜你登陆成功了!";
        }
        return "用户名或者是密码错误！";                                           //如果验证不通过，返回该信息
    }


    @RequestMapping(value = "/getUserList",method = RequestMethod.POST)
    @ApiOperation(value = "获取用户列表",httpMethod = "POST")
    public String getUserList(HttpServletRequest request,
                            @RequestBody User u){              //@RequestBody是用户需要传进来的参数
        /** 以管理员身份登录成功后获取用户列表，用户属性在com.course.bean.User里面定义的
         * SwaggerUI验证：传入json参数:{"userName":"zhangsan","password":"123456"}
         * jmeter验证：略，最后用jmeter验证，SwaggerUI不能穿cookies
         * @RequestBody这种参数，对应jmeter里面的Body Data */

        User user;
        //获取cookies
        Cookie[] cookies = request.getCookies();
        //验证cookies是否合法，假设 zhangsan 是管理员，并且登陆成功，才可以访问用户列表

        for(Cookie c : cookies){
            if(c.getName().equals("login")
                    && c.getValue().equals("true")
                    && u.getUserName().equals("zhangsan")
                    && u.getPassword().equals("123456")
                    ){
                user = new User();                             //创建用户列表
                user.setName("lisi");
                user.setAge("18");
                user.setSex("man");
                return  user.toString();
            }

        }

        return "参数不合法";
    }
}

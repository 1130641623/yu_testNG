package com.course.server;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

    /** MyGetMethod方法实现mock中返回cookie信息的服务 */
@RestController
@Api(value = "/",description = "这是我全部的get方法")
public class MyGetMethod {
    //SpringBoot框架的配置文件，必须是这个名字：application.properties
    //@RequestMapping注解：是接口本身的注解，value = "/getCookies" 是访问路径，method = RequestMethod.GET是访问方法
    //@ApiOperation是Swagger的注解，value用来描述接口是干什么的，httpMethod定义请求方法
    @RequestMapping(value = "/getCookies",method = RequestMethod.GET)
    @ApiOperation(value = "通过这个方法可以获取到Cookies",httpMethod = "GET")
    public String getCookies(HttpServletResponse response){                      //getCookies是方法名，自定义
        //HttpServerletRequest 装请求信息的类
        //HttpServerletResponse  装响应信息的类
        Cookie cookie = new Cookie("login","true");                 //对response信息添加响应cookies[1],浏览器F12就可以看到cookie信息
        response.addCookie(cookie);                                               //对response信息添加响应cookies[2]
        return "恭喜你获得cookies信息成功";
    }

    /**
     * 要求客户端携带cookies访问
     * 这是一个需要携带cookies信息才能访问的get请求，要验证携带cookie，用jmeter验证
     */
    @RequestMapping(value = "/get/with/cookies",method = RequestMethod.GET)
    @ApiOperation(value = "要求客户端携带cookies访问",httpMethod = "GET")
    public String getWithCookies(HttpServletRequest request){
        Cookie[] cookies = request.getCookies();             //返回多个key:value组成的数组
        if(Objects.isNull(cookies)){                         //判断对象是否为null空
            return "你必须携带cookies信息来";
        }
        for(Cookie cookie : cookies){
            if(cookie.getName().equals("login") &&
                    cookie.getValue().equals("true")){
                return "cookie验证通过，这是一个需要携带cookies信息才能访问的get请求!";
            }
        }

        return "你必须携带cookies信息来";
    }

    /**GET请求的带参访问方式一
     * 开发一个需要携带参数才能访问的get请求。主要学习点：@RequestParam
     * 第一种实现方式 url: key=value&key=value
     * 我们来模拟获取商品列表，通过浏览器访问验证：http://localhost:8888/get/with/param?start=100&end=200
     */
    @RequestMapping(value = "/get/with/param",method = RequestMethod.GET)
    @ApiOperation(value = "需求携带参数才能访问的get请求方法一",httpMethod = "GET")
    public Map<String,Integer> getList(@RequestParam Integer start,           //泛型为商品名称和商品价格。主要学习点：@RequestParam
                                       @RequestParam Integer end){            //@RequestParam 是参数注解，分页访问参数
        Map<String,Integer> myList = new HashMap<>();                         //定义商品列表

        myList.put("鞋",400);
        myList.put("干脆面",1);
        myList.put("衬衫",300);

        return  myList;

    }

    /**GET请求的带参访问方式二
     * 第二种需要携带参数访问的get请求.主要学习点：@PathVariable
     * url:ip:port/get/with/param/10/20
     * 通过浏览器访问验证：http://localhost:8888/get/with/param/10/20
     */
    @RequestMapping(value = "/get/with/param/{start}/{end}")         //访问路径与前面的区别，如果有若干个参数，继续添加斜杠和大括号
    @ApiOperation(value = "需求携带参数才能访问的get请求的第二种实现",httpMethod = "GET")
    public  Map myGetList(@PathVariable Integer start,               //主要学习点：@PathVariable。 参数注解与前面的区别
                          @PathVariable Integer end){

        Map<String,Integer> myList = new HashMap<>();

        myList.put("鞋",400);
        myList.put("干脆面",1);
        myList.put("衬衫",300);

        return  myList;

    }

}

package com.course.bean;


import lombok.Data;

@Data
public class User {
    /**使用步骤：
     1、安装插件
     2、pom.xml引入jar包
     3、*.java导入:import lombok.Data;
     4、在类上加注解:@Data*/
    private String userName;
    private String password;
    private String name;
    private String age;
    private String sex;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }
}

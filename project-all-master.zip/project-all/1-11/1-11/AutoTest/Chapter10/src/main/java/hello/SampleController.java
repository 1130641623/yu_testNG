package hello;

import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.*;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;

@Controller
@EnableAutoConfiguration
public class SampleController {
    /**第一个SpringBoot实例*/
    //SpringBoot是一个容器，它的导入方式，必须在最顶层的pom.xml文件里面导入
    //SpringBoot的内置web容器，端口默认是8080，浏览器访问地址：localhost:8080 | localhost:8888
    //如果运行SpringBoot没有报错，浏览器访问也没有结果，多半是端口被占用，或端口不对。
    @RequestMapping("/")
    @ResponseBody
    String home() {
        return "Hello World!";
    }

    public static void main(String[] args) throws Exception {
        SpringApplication.run(SampleController.class, args);
    }

    @SpringBootApplication
    @ComponentScan("com.course")
    public static class Application {

        public static void main(String[] args) {
            SpringApplication.run(Application.class,args);
        }    //SpringBoot入口类，固定写法
    }
}

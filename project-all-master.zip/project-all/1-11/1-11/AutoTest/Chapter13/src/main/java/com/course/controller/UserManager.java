package com.course.controller;


import com.course.model.User;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.log4j.Log4j;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Objects;

@Log4j
@RestController
@Api(value = "v1",description = "用户管理系统")
@RequestMapping("v1")
public class UserManager {

    @Autowired
    private SqlSessionTemplate template;

    @ApiOperation(value = "登陆接口",httpMethod = "POST")
    @RequestMapping(value = "/login",method = RequestMethod.POST)
    public Boolean login(HttpServletResponse response, @RequestBody User user){  //@RequestBody是用户需要传进来的参数
        int i = template.selectOne("login",user);                     //传入user的信息去数据库里面查询
        Cookie cookie = new Cookie("login","true");
        response.addCookie(cookie);
        log.info("查询到的结果是"+i);                               //将查询结果输出为日志
        if(i==1){
            log.info("登陆的用户是："+user.getUserName());          //将登陆用户信息输出为日志
            return true;                                           //返回true，则登录成功
        }
        return false;

    }

    @ApiOperation(value = "添加用户接口",httpMethod = "POST")
    @RequestMapping(value = "addUser",method = RequestMethod.POST)
    public boolean addUser(HttpServletRequest request,@RequestBody User user){
        Boolean x = verifyCookies(request);
        int result=0;
        if(x!=null){                                         //cookie验证通过，就执行添加用户的sql
            result = template.insert("addUser",user);
        }
        if(result > 0){
            log.info("添加用户的数量是："+result);
            return true;
        }
        return false;

    }

    @ApiOperation(value = "获取用户（列表）信息接口",httpMethod = "POST")
    @RequestMapping(value = "getUserInfo",method = RequestMethod.POST)
    public List<User> getUserInfo(HttpServletRequest request,@RequestBody User user){
        Boolean x = verifyCookies(request);
        if(x==true){                                      //cookie验证通过，就可以获取用户信息
            List<User> users = template.selectList("getUserInfo",user);
            log.info("getUserInfo获取到的用户数量是"+users.size());
            return users;
        }else {
            return null;
        }

    }

    @ApiOperation(value = "更新/删除用户接口",httpMethod = "POSt")
    @RequestMapping(value = "/updateUserInfo",method = RequestMethod.POST)
    public int updateUser(HttpServletRequest request,@RequestBody User user){
        Boolean x = verifyCookies(request);
        int i = 0;
        if(x==true){                                     //cookie验证通过，就可以执行SQL更新语句
            i = template.update("updateUserInfo",user);
        }
        log.info("更新数据的条目数为："+i);
        return i;
    }

    private Boolean verifyCookies(HttpServletRequest request) {
        /** 验证cookie的方法 */
        Cookie[] cookies = request.getCookies();
        if(Objects.isNull(cookies)){                        //判断cookie是否为空
            log.info("cookies为空");
            return  false;
        }

        for(Cookie cookie:cookies){
            if(cookie.getName().equals("login") &&            //判断cookie的名称
                    cookie.getValue().equals("true")){        //判断cooker的值
                log.info("cookies验证通过");
                return true;
            }
        }
        return false;
    }

}

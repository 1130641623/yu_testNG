package com.course.config;

import org.apache.http.client.CookieStore;
import org.apache.http.impl.client.DefaultHttpClient;
//类属性对应application.properties的5个接口路径，写完以后，开发一个拼接url的工具类
//定义一个接口地址对象，客户端对象，cookie对象
public class TestConfig {
    public static String loginUrl;
    public static String updateUserInfoUrl;
    public static String getUserListUrl;
    public static String getUserInfoUrl;
    public static String addUserUrl;


    public static DefaultHttpClient defaultHttpClient;
    public static CookieStore store;

}

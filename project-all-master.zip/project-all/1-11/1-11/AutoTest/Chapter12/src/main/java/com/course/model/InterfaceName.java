package com.course.model;

public enum InterfaceName {                                         //枚举类，对应5个接口
    GETUSERLIST,LOGIN,UPDATEUSERINFO,GETUSERINFO,ADDUSERINFO
}

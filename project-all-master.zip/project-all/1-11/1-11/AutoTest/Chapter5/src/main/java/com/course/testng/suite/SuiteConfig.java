package com.course.testng.suite;

import org.testng.annotations.*;
//该测试配置文件，对分层用例的当前用例层，进行配置。主要配置前置后置处理
// 这里配置完成后，需要把配置文件路径配置到*.xml文件里面去
public class SuiteConfig {

    @BeforeSuite
    public void beforeSuite(){
        System.out.println("before suite运行啦");
    }

    @AfterSuite
    public  void aftersuite(){
        System.out.println("after suite 运行啦");
    }

    @BeforeTest
    public void beforeTest(){
        System.out.println("beforeTest");
    }

    @AfterTest
    public void afterTest(){
        System.out.println("afterTest");
    }
}

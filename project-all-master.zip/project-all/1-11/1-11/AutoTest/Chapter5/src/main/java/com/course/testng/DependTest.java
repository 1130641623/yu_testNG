package com.course.testng;

import org.testng.annotations.Test;

public class DependTest {
    /**依赖测试，test2依赖于test1，如果test1失败了，test2就不执行，测试结果test2就是忽略*/
    @Test
    public void test1(){
        System.out.println("test1 run");
        throw new RuntimeException();     //这里不抛异常，就可以测试pass

    }

    @Test(dependsOnMethods = {"test1"})    //"test1"是依赖的方法名，是test2执行的先决条件
    public void test2(){
        System.out.println("test2 run");
    }

}

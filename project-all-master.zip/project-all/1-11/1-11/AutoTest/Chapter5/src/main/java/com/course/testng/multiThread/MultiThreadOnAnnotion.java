package com.course.testng.multiThread;

import org.testng.annotations.Test;

public class MultiThreadOnAnnotion {
    /**多线程测试*/
    @Test(invocationCount = 10,threadPoolSize = 3)    //3个线程同时运行，3个线程总共执行10次
    public void test(){
        System.out.println(1);
        System.out.printf("Thread Id : %s%n",Thread.currentThread().getId());
    }

}

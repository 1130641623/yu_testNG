package com.course.testng.paramter;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.lang.reflect.Method;

public class DataProviderTest {
    /** 参数化测试，这里会将 providerData 方法里的数据传入到 testDataProvider 方法里面，用name和age来接收 */
    @Test(dataProvider = "data")
    public void testDataProvider(String name,int age){
        System.out.println("name =" + name +"; age=" + age);
    }

    @DataProvider(name="data")           //通过该注解，将数据传进去，name的值要与接收数据的用例的dataProvider值对应
    public Object[][] providerData(){    //创建数组，并返回数组。这里的二维数组有几个1维数组，接收数据的用例就会运行几次
        Object[][] o = new Object[][]{
                {"zhangsan",10},
                {"lisi",20},
                {"wangwu",30}
        };

        return o;
    }

    //========================= 根据不同的用例传递不同的参数 ============================
    @Test(dataProvider = "methodData")
    public void test1(String name,int age){
        System.out.println("test111方法 name="+name+";age="+age);
    }
    @Test(dataProvider = "methodData")
    public void test2(String name,int age){
        System.out.println("test222方法 name="+name+";age="+age);
    }

    @DataProvider(name="methodData")
    public Object[][] methodDataTest(Method method){    //Method是一个Java类
        Object[][] result=null;                         //根据方法不同(用例不同)，给result赋值

        if(method.getName().equals("test1")){
            result = new Object[][]{
                    {"zhangsan",20},
                    {"lisi",25}
            };
        }else if(method.getName().equals("test2")){
            result = new Object[][]{
                    {"wangwu",50},
                    {"zhaoliu",60}
            };
        }

        return result;
    }



}

package com.course.controller;


import com.course.model.User;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.log4j.Log4j;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Log4j
@RestController
@Api(value = "v1",description = "这是我的第一个版本的demo")  //@Api里面的value与@RequestMapping的value对应，必须一致
@RequestMapping("v1")
public class Demo {

    //首先获取一个执行sql语句的对象
    //@Autowired注解表示启动器加载，这样SqlSessionTemplate就会被加载
    @Autowired
    private SqlSessionTemplate template;

    @RequestMapping(value = "/getUserCount",method = RequestMethod.GET)     //编写接口
    @ApiOperation(value = "可以获取到用户数",httpMethod = "GET")              //@ApiOperation是Swagger的注解
    public int getUserCount(){
        /** 第一个mybatis Demo : SQL查询
         * Demo的getUserCount方法启动方式：启动Application > 浏览器访问：/getUserCount */
       //getUserCount是mysql.xml文件里面select标签的id
        return template.selectOne("getUserCount");
    }

    @RequestMapping(value = "/addUser",method = RequestMethod.POST)
    public int addUser(@RequestBody User user){                         //@RequestBody是用户需要传进来的参数
        /** SQL插入语句 insert语句
         * 这里用的是post方法，就要用到model ，model与SQL表结构字段相对应 */
        int result = template.insert("addUser",user);
        return result;
    }

    @RequestMapping(value = "/updateUser",method = RequestMethod.POST)
    public int updateUser(@RequestBody User user){

       return  template.update("updateUser",user);

    }

    @RequestMapping(value = "/deleteUser",method = RequestMethod.GET)
    public int delUser(@RequestParam int id){
        return template.delete("deleteUser",id);
    }

}

package com.course.model;

import lombok.Data;

@Data
public class User {
    private int id;
    private String name;
    private String sex;
    private int age;

}
